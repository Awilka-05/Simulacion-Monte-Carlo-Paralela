import numpy as np, time, csv, multiprocessing as mp

GRID_N,DAYS,BETA,GAMMA,MU,INIT_INF,SEED = 1000,365,0.30,0.05,0.002,0.001,42

def init_grid(n,ii,s):
    rng=np.random.default_rng(s); g=np.zeros((n,n),dtype=np.int8)
    g[rng.random((n,n))<ii]=1; return g

def worker_step(args):
    blk,beta,gamma,mu,so,day=args; rng=np.random.default_rng(so+day*997)
    S,I=(blk==0),(blk==1)
    inf_n=sum(np.roll(I,d,a).astype(np.float32) for d,a in[(1,0),(-1,0),(1,1),(-1,1)])
    p=1-(1-beta)**inf_n; ni=S&(rng.random(blk.shape,dtype=np.float32)<p)
    nr=I&(rng.random(blk.shape,dtype=np.float32)<gamma)
    nd=I&~nr&(rng.random(blk.shape,dtype=np.float32)<mu)
    g=blk.copy();g[ni]=1;g[nr]=2;g[nd]=3; return g[1:-1,:]

def split(grid,nb):
    n=grid.shape[0];sz=n//nb;blocks=[]
    for i in range(nb):
        r0,r1=i*sz,(r0+sz if i<nb-1 else n)
        blocks.append(np.vstack([grid[(r0-1)%n,:].reshape(1,-1),grid[r0:r1,:],grid[r1%n,:].reshape(1,-1)]))
    return blocks

def count(g): return {k:int(np.sum(g==v)) for k,v in zip("SIRD",range(4))}

if __name__=="__main__":
    nc=mp.cpu_count(); g=init_grid(GRID_N,INIT_INF,SEED)
    seeds=[SEED+(b+1)*100003 for b in range(nc)]; t0=time.perf_counter()
    with mp.Pool(nc) as pool:
        for day in range(DAYS):
            blks=split(g,nc)
            new_blks=pool.map(worker_step,[(b,BETA,GAMMA,MU,seeds[i],day) for i,b in enumerate(blks)])
            g=np.vstack(new_blks)
    print(f"Done {time.perf_counter()-t0:.1f}s")
